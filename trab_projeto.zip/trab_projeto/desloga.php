<?php
session_start();
// $_SESSION['teste']=0;

?>
<h1><center>Loading...</h1></center>
<br>
<center><h2>Goodbye 
<?php 
echo $_SESSION['nome']."</h2></center> ";

$_SESSION['logado']=0;

?>

<meta http-equiv="refresh" content="2; url='index.php">