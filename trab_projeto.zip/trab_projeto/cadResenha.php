<?php

include 'cabecalho.php';
if (isset($_SESSION['logado'])) {

  if($_SESSION['logado']==1){

?>
<div class="um">
<form method="post" action="sugestaoResenha.php" enctype="multipart/form-data">
<div class="ui segment">
  <div class="ui form">
  <div class="field">
    <label>Review Name</label>
    <input type="text" name="NomeResenha" placeholder="Review Name" required="This is important">
  </div>
<div class="field">
    <div class="field aqui">
      <label>Category</label>
      <div class="ui fluid search selection dropdown ">
        <input type="hidden" name="categoriaa">
        <i class="dropdown icon"></i>

        <div class="default text">Select Category</div>

        <div class="menu">

    <div class="item" data-value="RPG"><i class=""></i>RPG</div>
    <div class="item" data-value="FPS"><i class=""></i>FPS</div>
    <div class="item" data-value="Survival"><i class=""></i>Survival</div>
    <div class="item" data-value="Creative"><i class=""></i>Creative</div>

  </div>
       </div>
    </div>
  </div>
<div class="field">
    <label>Creation year</label>
    <input type="number" name="data" placeholder="Creation Date" required="This is important" max="2020" min="1000">
  </div>

  <div class="field">
    <label>First image</label>
    <input type="file" name="um" placeholder="Insert" required="This is important" >
  </div>

  <div class="field">
    <label>Second image</label>
    <input type="file" name="dois" placeholder="Insert" required="This is important" >
  </div>




<div class="field">
    <label>Review</label>
    <textarea placeholder="Review" name="resenha" required="This is important"></textarea>
  </div>
  <div class="field">
    <label>Message to Admin</label>
    <input type="text" name="mensagem" placeholder="Message to Adim" >
  </div>
  <div class="field">
    <label>Author Name</label>
    <input type="text" name="autor" placeholder="Author Name" >
  </div>
<div class="ui segment">
    <div class="field">
      <div class="ui toggle checkbox">
        <input type="checkbox" name="gift" tabindex="0" class="hidden">
        <label>Would you like to receive news of your review by email?</label>
      </div>
    </div>
  </div>

 <button class="ui button" type="submit">Submit</button>
</div>
</div>
</form>
</div>
<br>	

<?php
}else{


?>
<center>
  <h1>You must be logged in to suggest a review</h1>
  <br>
  <a href="login.php">
  <h2>Login</h2>
</a>
</center>

<div class="rodape"></div>
 <?php

} 
}else{

	echo'
	<center>
  <h1>You must be logged in to suggest a review</h1>
  <br>
  <a href="login.php">
  <h2>Login</h2>
</a>
</center>

<div class="rodape"></div>'

;

}
include 'rodape.php';
