<?php 
include("cabecalho.php");

?>
<div class="marginTop "></div>

<h1 class="centra">Game Suggestions</h1>
<div class="ui grid center aligned page grid">


<?php

  $lista=listaResenhas();

  $tam=sizeof($lista);
  //print_r($tam);

  //shuffle($lista);



  foreach ($lista as $dados) {

if ($dados['cod']<=$tam) {
    echo('
      
      <!-- Item-->

      
      <div class="five wide column">

      <div class="ui special cards">
      <div class="card">

      <div class="blurring dimmable image">
      <div class="ui dimmer">
      <div class="content">
      <div class="center">
      <a href="detalhaResenha.php?cod='.$dados['cod'].'">
      <div class="ui inverted button">Abrir</div>
      </a>
      </div>
      ');

    if($_SESSION['nome']=='admin' and $_SESSION['logado']==1){

echo'
<!-- AKI -->
      <div class="ui basic modal cont'.$dados['cod'].'">
      <div class="ui icon header">
      <i class="archive icon"></i>
      Deseja mesmo excluir a resenha?
      </div>
      <div class="content">
      <p>Your inbox is getting full, would you like us to enable automatic archiving of old messages?</p>
      </div>
      <div class="actions">
      <div class="ui red basic cancel inverted button">
      <i class="remove icon"></i>
      No
      </div>
      <div class="ui green ok inverted button">
      <i class="checkmark icon"></i>
      Yes
      </div>
      </div>
      </div>
';



    echo'
      
      <br>
      <div class="ui inverted button"><i class="pencil alternate icon medium teal"></i></div>
      

  
      
      <div id="'.$dados['cod'].'" class="ui inverted button vemModal "><i class="window close icon medium red"></i></div>
      
      ';
      }

      echo'


      </div>
      </div>
      <img src="imagens/'.$dados['imagem1'].'">
    
    </div>
      <div class="content">
      <a class="header" href="detalhaResenha.php?cod='.$dados['cod'].'">'.$dados['nome'].'</a>
      <div class="meta">
      <span class="date">'.$dados['info'].'</span>
      </div>
      </div>

      <div class="extra content">
     
      <i class="'.$dados['icone'].' icon"></i>
      '.$dados['categoria'].'
     
      </div>
      
    
      </div>
    
     
      </div>
      </div>

      '; 
  }
}

  ?>
  <!-- Fim do tem-->

</div>
</div>

<?php

include ("rodape.php");
?>