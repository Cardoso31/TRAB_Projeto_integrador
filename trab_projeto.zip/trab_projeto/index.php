<?php 
include("cabecalho.php");
?>


<div class="marginTop "></div>

<h1 class="centra">Game Suggestions</h1>
<div class="ui grid center aligned page grid">


<div class="ui special cards">
  <div class="card">
    <div class="blurring dimmable image">
      <div class="ui dimmer">
        <div class="content">
          <div class="center">
            <div class="ui inverted button">Add Friend</div>
          </div>
        </div>
      </div>
      <img src="imagens/semFoto.jpeg">
    </div>
   
   
  </div>
</div>
  <?php

  $lista=listaResenhas();

  $tam=sizeof($lista);
  //print_r($tam);
  
  foreach ($lista as $dados) {

if ($dados['cod']<=$tam) {
    echo('
      <!-- Item-->

      
      <div class="four wide column">
      <div class="ui card grey">
      <a href="detalhaResenha.php?cod='.$dados['cod'].'">
      <div class="ui slide masked reveal image">
      <img src="imagens/'.$dados['imagem1'].'" class="visible content ">
      <img src="imagens/'.$dados['imagem2'].'" class="hidden content">
      </div>
      <div class="content">
      <a class="header" href="detalhaResenha.php?cod='.$dados['cod'].'">'.$dados['nome'].'</a>
      <div class="meta">
      <span class="date">'.$dados['info'].'</span>
      </div>
      </div>
      <div class="extra content">
     
      <i class="'.$dados['icone'].' icon"></i>
      '.$dados['categoria'].'
     
      </div>

      </a>
      </div>
       <a href="editar.php?imagem='.$dados['cod'].'">  <i class="pencil alternate icon medium teal"></i> </a>

      <a href="excluir.php?imagem='.$dados['cod'].'">  <i class="window close icon medium teal"></i> </a>


      </div>
      '); 
  }
}

  ?>
  <!-- Fim do tem-->

</div>
</div>

<?php

include ("rodape.php");
?>