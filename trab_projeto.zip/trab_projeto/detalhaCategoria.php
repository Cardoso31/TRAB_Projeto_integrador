<?php 
include 'cabecalho.php';
$codigo=$_GET['cod2'];

$categorias=array(1=>'RPG', 2=>'FPS',3=>'Survival',4=> 'Creative');


$lista=buscaCategoria($categorias[$codigo]);
echo '
      <h1 class="centra">'.$lista[1]["categoria"].'  Games</h1>
      <div class="marginTop "></div>
      <div class="ui grid center aligned page grid">'
      ;
 foreach ($lista as $dados) {
    echo('
      
      
      <div class="five wide column">

      <div class="ui special cards">
      <div class="card">

      <div class="blurring dimmable image">
      <div class="ui dimmer">
      <div class="content">
      <div class="center">
      <a href="detalhaResenha.php?cod='.$dados['cod'].'">
      <div class="ui inverted button">Abrir</div>
      </a>
      </div>
      ');

    if($_SESSION['nome']=='admin' and $_SESSION['logado']==1){
    echo'

      <br>
      <div>
      <div class="ui inverted button"><a href="editar.php?imagem='.$dados['cod'].'">  <i class="pencil alternate icon medium teal"></i> </a></div>
      </div>

      <br>
      <div>
      <div class="ui inverted button"><a href="excluir.php?imagem='.$dados['cod'].'">  <i class="window close icon medium red"></i> </a></div>
      </div>
      ';
      }

      echo'


      </div>
      </div>
      <img src="imagens/'.$dados['imagem1'].'">
    
    </div>
      <div class="content">
      <a class="header" href="detalhaResenha.php?cod='.$dados['cod'].'">'.$dados['nome'].'</a>
      <div class="meta">
      <span class="date">'.$dados['info'].'</span>
      </div>
      </div>
      <div class="extra content">
     
      <i class="'.$dados['icone'].' icon"></i>
      '.$dados['categoria'].'
     
      </div>
      
    
      </div>
    
     
      </div>
      </div>

      '           ; 
  }

?>
</div>
</div>
<?php
include "rodape.php";
