<?php
include'cabecalho.php';
?>
<center>
<h1>Your images are in the wrong format</h1>
<h2>Make sure the images are right</h2>
</center>