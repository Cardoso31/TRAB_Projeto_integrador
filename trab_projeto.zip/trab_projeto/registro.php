<?php
include 'cabecalho.php';
?>
<div class="um">
  <form method="post" action="gravaUsuario.php">
    <div class="ui segment">
      <div class="ui form">
        <div class="field">
          <label>First Name</label>
          <input type="text" name="primeiroNome" placeholder="First Name" required="This is important">
        </div>
        <div class="field">
          <label>Last Name</label>
          <input type="text" name="ultimoNome" placeholder="Last Name" required="This is important">
        </div>
        <div class="field">
          <label>Age</label>
          <input type="Number" name="idade" placeholder="Age" required="This is important" min="10">
        </div>
        <div class="field">
          <label>E-mail</label>
          <input type="email" name="email" placeholder="E-mail" required="This is important">
        </div>
        <div class="field">
          <label>Nickname</label>
          <input type="text" name="nomeusuario" placeholder="Nickname" required="This is important">
        </div>
        <div class="field">
          <label>Password</label>
          <input type="password" name="password" placeholder="Password" required="This is important">
        </div>
        <div class="ui segment">
          <div class="field">
            <div class="ui toggle checkbox">
              <input type="checkbox" name="gift" tabindex="0" class="hidden">
              <label>Would you like to receive news by email?</label>
            </div>
          </div>
        </div>

        <button class="ui button" type="submit">Submit</button>
      </div>
    </div>
  </form>
</div>
<div class="espaco"></div>
<br>	
<?php
include 'rodape.php';
?>