
<br>
 <div class="ui inverted vertical footer segment rodape">
    <div class="ui center aligned container">
      <div class="ui stackable inverted divided grid">
        <div class="three wide column centered">
          <h4 class="ui inverted header">Developers</h4>
          <div class="ui inverted link list">
            <a href="https://www.instagram.com/_allinesoster/" class="item">Aline Soster</a>
            <a href="https://www.instagram.com/b0sskiller1/" class="item">Dimitri Miranda</a>
            <a href="https://www.instagram.com/mat_mcardoso/" class="item">Mateus Cardoso</a>
          </div>
        </div>
        
        <div class="seven wide column">
          <h4 class="ui inverted header">Open World</h4>
          <p>Your site for consults of games.</p>
        </div>
      </div>
      <br>
      <br>
      <a href="https://www.facebook.com/mateus.cardoso.94801116" target="_blank">
      <button class="grey ui facebook button">
  <i class="facebook icon"></i>
  Facebook
</button>
</a>
<a href="https://www.facebook.com/mateus.cardoso.94801116" target="_blank">
<button class="grey ui twitter button">
  <i class="twitter icon"></i>
  Twitter
</button>
</a>
<a href="https://www.instagram.com/mat_mcardoso/" target="_blank">
<button class=" grey ui instagram button">
  <i class="instagram icon"></i>
  Instagram
</button>
</a>
<br>
      <div class="ui horizontal inverted small divided link list">
        <a class="item" href="#">Site Map</a>
        <a class="item" href="#">Contact Us</a>
        <a class="item" href="#">Terms and Conditions</a>
        <a class="item" href="#">Privacy Policy</a>
      </div>
    </div>
</div>
</body>
</html>