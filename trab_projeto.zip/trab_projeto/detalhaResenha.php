<?php
include "cabecalho.php";
// print_r($_SESSION); 
// print_r($_GET);


$codigo=$_GET['cod'];

$jogo=buscaResenha($codigo);
?>

<div class="gridDupla">

	<div class="imagem">

<?php

	echo'
<div class="ui four column grid">

  <div class="column">
    <div class="ui fluid image">
      <div class="ui white ribbon label">
        <a class="header"><i class="'.$jogo["icone"].' outline icon black large"></i> '.$jogo["categoria"].'</a>
      </div>
      <div class="fotoResenha">
          <img src="imagens/'.$jogo["imagem1"].'">
    </div>
  </div>
</div>

  <div class="resenha">
 ';



if (isset($_SESSION['logado'])) {

    if ($_SESSION['nome']=='admin' and $_SESSION['logado']==1) {
       

echo'
       <div class="ui icon top left pointing dropdown flutua">
        
          <a href="excluir.php?imagem='.$codigo.'">  <i class="pencil alternate icon big teal"></i> </a>
          
          <a href="editar.php?imagem='.$codigo.'">  <i class="window close icon big teal "></i> </a>

          
      
      </div>';
}
}

echo'
  <h1 class="nomeResenha">'.$jogo['nome'].'</h1>
  <div class="texto">
    <h3>'.$jogo["resenha"].'</h3>
  </div>
  <br>
  <h4 class="autor">Autor: '.$jogo["autor"].'</h4>
  </div>
</div>
</div>
</div>
<div class="rodaresenha"></div>'
;
include ("rodape.php");
?>


