<?php
include "funcoes.php";
$user=$_POST['user'];
$senha=$_POST['senha'];

// print_r($_POST['user']);

// echo "<br>";


// print_r($_POST['senha']);

// echo "<br>";

$testa=testaUsuario($user,$senha);

 // print_r($testa);

// echo "<br>";
if(isset($_SESSION['nome'])){
	$nome=$_SESSION['nome'];
}

if($testa==0){
	$teste=0;
}elseif($testa==1) {
	$teste=1;
}else{
	$teste=0;
}

if($teste==1){

	echo "
	<center>
	<h1>Logged</h1>
	<br>
	<br>
	<h1>Welcome ".$nome."</h1>
	</ssscenter>
	";
	echo "<meta http-equiv='refresh' content='3; url=index.php?testa=1'>";
}else{
	echo "<center><h1>Invalid data</h1></center>";
	echo "<meta http-equiv='refresh' content='2; url=login.php'>";
}