<?php
include 'cabecalho.php';
?>
<div class="ui two column grid">
  <div class="column">
    <div class="ui fluid image">
      <div class="ui black ribbon label">
        <a class="header"><i class="'.$jogo["icone"].' icon"></i> '.$jogo["categoria"].'</a>
      </div>
          <img src="imagens/'.$jogo["imagem1"].'">
    </div>
  </div>
  <div class="column">
    <div class="ui fluid image">
      <div class="ui blue ribbon label">
        <a class="header"><i class="'.$jogo["icone"].' icon"></i> '.$jogo["categoria"].'</a>
      </div>
           <img src="imagens/'.$jogo["imagem1"].'">
    </div>
  </div>
</div>