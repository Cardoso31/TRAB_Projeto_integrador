<?php
include 'cabecalho.php';

$resenha=buscaResenha($_GET['imagem']);
echo"<pre>";
print_r($resenha);
echo"</pre>";

